﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Conf.Infrastructure;
using Conf.Models;
using WebApiContrib.Formatting.Jsonp;

namespace Conf.Controllers
{
    [Route("Conference/{section}/info")]
    public class SectionController : ControllerBase
	{
        private readonly ISectionStorage _sectionStorage;
		private readonly SectionJsonMapper _sectionJsonMapper;
        private readonly System.Web.Http.HttpConfiguration _httpConfig;

		public SectionController(
			ISectionStorage sectionStorage, 
			SectionJsonMapper  sectionJsonMapper,
            System.Web.Http.HttpConfiguration config) {

			_sectionStorage = sectionStorage ?? throw new ArgumentNullException(nameof(sectionStorage));
			_sectionJsonMapper = sectionJsonMapper ?? throw new ArgumentNullException(nameof(sectionJsonMapper));
            _httpConfig = config ?? throw new ArgumentNullException(nameof(config));

            _httpConfig.Formatters.Insert(0, new JsonpMediaTypeFormatter(config.Formatters.JsonFormatter));
        }


		[HttpGet]
        public async Task<IActionResult> Get([FromRoute] string section) {
            var sec = await _sectionStorage.GetSection(section);

            if (sec == null)
                return NotFound();

			return new JsonResult(_sectionJsonMapper.ToJson(sec));
		}	


        [HttpPut]
        public async Task<bool> Put([FromRoute] string section, [FromBody] SectionInfo info) =>
		   await _sectionStorage.Update(
				_sectionJsonMapper.ToSection(section, info));


		[HttpPost]
		public async Task<bool> Post([FromRoute] string section, [FromBody] SectionInfo info) =>
			await _sectionStorage.Insert(
				_sectionJsonMapper.ToSection(section, info));

	}
}