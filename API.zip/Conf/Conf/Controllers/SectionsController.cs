﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Conf.Infrastructure;
using Microsoft.AspNetCore.Cors;

namespace Conf.Controllers
{
    [Route("Conference/info")]
    public class SectionsController : ControllerBase
    {
        private readonly ISectionStorage _sectionStorage;
		private readonly SectionJsonMapper _sectionJsonMapper;

        public SectionsController(
			ISectionStorage sectionStorage,
			SectionJsonMapper sectionJsonMapper) {

			_sectionStorage = sectionStorage ?? throw new ArgumentNullException(nameof(sectionStorage));
			_sectionJsonMapper = sectionJsonMapper ?? throw new ArgumentNullException(nameof(sectionJsonMapper));
        }

		[HttpGet]
		public async Task<JsonResult> Get() =>
			new JsonResult(
				(await _sectionStorage.GetSections())
				    ?.Select(s => _sectionJsonMapper.ToJson(s))
			); 
    }
}