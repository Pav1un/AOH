﻿using System; 
using Map.Ziper;




namespace Map
{  
    class Program
    {  
        static void Main(string[] args)
        {
            #if DEBUG
                args = new[] {
                    @"C:\Users\rb064031\Downloads\csharp language specification.doc",
                    @"D:\test.gz"
                };
            #endif

            if (args.Length < 1) {
                Console.WriteLine("Укажите по крайней мере исходный файл: program (source file) [destination file]");
                Environment.Exit(0);
            }

            var zipFactory = ZipFactoryCreator.GetFactory();

            if (zipFactory == null)
                throw new Exception("No suitable zip implementation for current environment");

            using (var slicer = zipFactory.GetSlicer(args[0])) {
                var compressor = zipFactory.GetCompressor(slicer.GetDestinationQueue());

                using (var saver = zipFactory.GetSaver(args.Length > 1 ? args[1] : null, compressor.GetDestinationQueue())) {
                    var runner = zipFactory.GetRunner();
                    runner.Run(slicer, compressor, saver);
                }
            }  
        }
       
    }
}

