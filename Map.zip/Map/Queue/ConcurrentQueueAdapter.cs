﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;

namespace Map.Queue
{
    public class ConcurrentQueueAdapter : QueueAdapter
    {
        private readonly ConcurrentQueue<byte[]> _queue = new ConcurrentQueue<byte[]>();

        public override int Count => _queue.Count;

        public override bool IsEmpty => _queue.Count < 1;

        public override void Clear() => _queue.Clear();

        public override byte[] Dequeue() {
            if (_queue.TryDequeue(out var item))
                return item;

            return null;
        }


        public override void Enqueu(byte[] item) => _queue.Enqueue(item);
    }
}
