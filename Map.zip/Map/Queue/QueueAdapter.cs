﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Map.Queue
{
    public abstract class QueueAdapter
    {
        public abstract void Enqueu(byte[] item);
        public abstract byte[] Dequeue();
        public abstract int Count { get; }
        public abstract bool IsEmpty { get; }
        public abstract void Clear();
    }
    
}
