﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Map.Queue
{
    public class OriginalQueueAdapter : QueueAdapter
    {
        public OriginalQueueAdapter() =>
            _queue = new Queue<byte[]>();

        public OriginalQueueAdapter(int capacity) =>
            _queue = new Queue<byte[]>(capacity);

        private readonly Queue<byte[]> _queue; 

        public override int Count => _queue.Count;

        public override void Clear() =>
            _queue.Clear();

        public override bool IsEmpty => _queue.Count < 1;

        public override byte[] Dequeue() => _queue.Dequeue();


        public override void Enqueu(byte[] item) => _queue.Enqueue(item);
    }
}
