﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Runtime.InteropServices;
using System.Text;

namespace Map.Tools
{
    public class FileMemoryMapper : IDisposable
    {
        private MemoryMappedFile _memMappedFile;

        public FileMemoryMapper(string path) {

            if (!File.Exists(path))
                throw new Exception("No file for zip");

            _memMappedFile = MemoryMappedFile.CreateFromFile(path, FileMode.Open, $"Img{DateTime.UtcNow}");
        }

        public byte[] GetBytesForRegion(long offset, long size) {
            if (_memMappedFile == null)
                throw new Exception("Initialize is required");

            byte[] arr;

            using (var a = _memMappedFile.CreateViewAccessor(offset, size))
                arr = UnmanagedCopy(a, size);


            return arr;
        }

        private unsafe byte[] UnmanagedCopy(MemoryMappedViewAccessor a, long size) {
            byte* ptr = null;
            byte[] arr = new byte[size];

            a.SafeMemoryMappedViewHandle.AcquirePointer(ref ptr);
            Marshal.Copy((IntPtr)ptr, arr, 0, (int)size);

            return arr;
        }

        public void Dispose() => _memMappedFile?.Dispose();
    }
}
