﻿using System;
using System.Runtime.InteropServices;



namespace Map.Configurations
{
    public enum MemSize
    {
        mb,
        gb,
        kb,
        bt
    }

    public static class PCConfiguration
    {
        [DllImport("kernel32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool GetPhysicallyInstalledSystemMemory(out long TotalMemoryInKilobytes);

        private static long _inKbMemSize = -1;

        public static long GetMemSize(MemSize sizeType = MemSize.mb) {
            if (_inKbMemSize == -1)
                GetPhysicallyInstalledSystemMemory(out _inKbMemSize);

            switch (sizeType) {
                case MemSize.bt:
                    return _inKbMemSize * 1024;
                case MemSize.gb:
                    return _inKbMemSize / 1048576;
                case MemSize.mb:
                    return _inKbMemSize / 1024;

                default:
                    return _inKbMemSize;
            }
        }

        public static int GetProcCount() => Environment.ProcessorCount;
    }
}
