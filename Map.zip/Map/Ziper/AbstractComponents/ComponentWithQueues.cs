﻿using Map.Queue;
using System;


namespace Map.Ziper
{
    public abstract class ComponentWithQueues
    {
        protected enum ComponentState
        {
            canRunFurther,
            finished,
            stopped
        }

        protected class State
        {
            public State(ComponentState initState) => CurrentState = initState;

            public ComponentState CurrentState { get; private set; }

            public void NextState() {
                switch (CurrentState) {
                    case ComponentState.canRunFurther:
                        CurrentState = ComponentState.finished;
                        break;
                    case ComponentState.finished:
                        CurrentState = ComponentState.stopped;
                        break;
                    default:
                        break;
                }
            }
        }

        protected readonly QueueAdapter _sourceQueue;
        protected QueueAdapter _destinationQueue;

        protected ComponentWithQueues(QueueAdapter sourceQueue) {
            _sourceQueue = sourceQueue ?? throw new ArgumentNullException(nameof(sourceQueue));
            _destinationQueue = GetDestQueue();
        }
        
        public virtual QueueAdapter GetSourceQueue() => _sourceQueue;
        public virtual QueueAdapter GetDestinationQueue() => _destinationQueue;
        protected abstract QueueAdapter GetDestQueue();
        public virtual void Finish() { }
    }
}
