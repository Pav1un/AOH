﻿using System;



namespace Map.Ziper
{
    public interface ICanRunComponent
    {
        void Run(Action<ICanRunComponent> onEndRun = null);
    }
}
