﻿using Map.Configurations;
using System;
using System.Collections.Generic;
using System.Text;

namespace Map.Ziper
{
    public static class ZipFactoryCreator
    {
        public static ZIPFactory GetFactory() {
            switch (PCConfiguration.GetProcCount()) {
                case 2:
                    return new ZIP2ThreadsFactory();

                case int c when (c > 2):
                    return new ZIP3ThreadsFactory();

                default:
                    return new ZIPFactory();
            } 
        }
    }
}
