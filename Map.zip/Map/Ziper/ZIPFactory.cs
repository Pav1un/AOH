﻿using Map.Configurations;
using Map.Queue;
using Map.Tools;
using System; 
using System.IO;
using System.IO.Compression;

namespace Map.Ziper
{
    public class ZIPFactory
    {
        public virtual Slicer GetSlicer(string path) => new Slicer(path);
        public virtual Compressor GetCompressor(QueueAdapter queue) => new Compressor(queue);
        public virtual Saver GetSaver(string path, QueueAdapter queue) => new Saver(path, queue);
        public virtual Runner GetRunner() => new Runner();
    }
    
    public class Slicer : ComponentWithQueues, ICanRunComponent, IDisposable
    {   
        protected State _state;
        protected long _step;
        protected long _offset;

        protected FileInfo _fileInfo;
        protected FileMemoryMapper _fileMemoryMapper;

        public Slicer(string filePath, QueueAdapter sourceQueue = null)
            : base(sourceQueue ?? new OriginalQueueAdapter()) //only for uniform work 
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Not found file for zip");

            _fileInfo = new FileInfo(filePath);

            _fileMemoryMapper = new FileMemoryMapper(filePath);

            _step = GetStepSize();

            _state = new State(ComponentState.canRunFurther);
        }

        public virtual void Run(Action<ICanRunComponent> onEndRun = null) {
            if (_state.CurrentState == ComponentState.canRunFurther)
                Slice();

            if (_state.CurrentState == ComponentState.finished) {
                onEndRun?.Invoke(this);
                _state.NextState();
            }
        }

        protected virtual void Slice( ) { 

            while ( _destinationQueue.Count <= 5 
                   && _state.CurrentState == ComponentState.canRunFurther)
            {
                if (_offset + _step < _fileInfo.Length) {
                    Enqueu(_offset, _step);
                    _offset += _step;
                } else {
                    if (_offset < _fileInfo.Length)
                        Enqueu(_offset, _fileInfo.Length - _offset);

                    _state.NextState();
                }
            }

            void Enqueu(long offset, long size) =>
                _destinationQueue.Enqueu(
                    _fileMemoryMapper.GetBytesForRegion(offset, size)
                );
        }

        protected long GetStepSize() =>
            GetGoodStepSize(GetStartStepSize(), _fileInfo.Length);

        protected virtual long GetGoodStepSize(int startBound, long fileSize) {

            if (fileSize / startBound < 1) 
                return fileSize;

            return startBound;
        }

        protected virtual int GetStartStepSize() =>
            Convert.ToInt32(PCConfiguration.GetMemSize(MemSize.bt) * 0.1); //10% from all memory


        protected override QueueAdapter GetDestQueue() =>
            new OriginalQueueAdapter();

        public virtual void Dispose() => _fileMemoryMapper.Dispose();
    }

    public class Compressor : ComponentWithQueues, ICanRunComponent
    {
        public Compressor(QueueAdapter queue) : base(queue) { }

        public virtual void Run(Action<ICanRunComponent> onEndRun = null) {
            byte[] src;

            while (!_sourceQueue.IsEmpty) {
                src = _sourceQueue.Dequeue();
                if (src == null) continue;

                //rethink
                using (MemoryStream memStream = new MemoryStream()) {
                    using (GZipStream compressionStream = new GZipStream(memStream, CompressionMode.Compress)) {
                        compressionStream.Write(src, 0, src.Length);
                    }

                    _destinationQueue.Enqueu(memStream.ToArray());
                }
            }
        }

        protected override QueueAdapter GetDestQueue() =>
           new OriginalQueueAdapter();
    }

    public class Saver : ComponentWithQueues, ICanRunComponent, IDisposable
    {
        protected string _resultFilePath;
        protected FileStream _fileStream;

        public Saver(string resultFilePath, QueueAdapter queue) : base(queue) =>
            _resultFilePath = resultFilePath ?? $@"zipResult_{DateTime.UtcNow}.zip"; 


        public virtual void Run(Action<ICanRunComponent> onEndRun = null) {

            if (_fileStream == null)
                _fileStream = File.Create(_resultFilePath);

            if (!_sourceQueue.IsEmpty) {

                using (var mem = new MemoryStream()) {
                    while (!_sourceQueue.IsEmpty)
                        mem.Write(_sourceQueue.Dequeue());

                    _fileStream.Write(mem.ToArray());
                } 
            } 
        }

        public void Dispose() => ((IDisposable)_fileStream).Dispose();

        protected override QueueAdapter GetDestQueue() => null;
    }

    public class Runner
    {
        protected volatile bool _isCompleted;

        public virtual void Run(
            Slicer slicer,
            Compressor compressor,
            Saver saver) 
        {

            if (slicer == null || compressor == null || saver == null)
                throw new Exception(ComponentsIsRequiredExceptionText);


            while (!_isCompleted) {
                slicer.Run((comp) => _isCompleted = true);
                compressor.Run();
                saver.Run();
            }
        }

        protected string ComponentsIsRequiredExceptionText =
            "Slicer, compressor and saver is requried";
    }

}
