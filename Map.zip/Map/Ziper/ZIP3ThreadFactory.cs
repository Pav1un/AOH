﻿using Map.Queue;
using System; 
using System.Threading; 




namespace Map.Ziper
{
    public class ZIP3ThreadsFactory : ZIP2ThreadsFactory
    {
        public override Compressor GetCompressor(QueueAdapter queue) => 
            new CompressorFor3Threads(queue);
        public override Saver GetSaver(string path, QueueAdapter queue) => 
            new Saver(path, queue);
        public override Runner GetRunner() => new RunnerFor3Threads();
    } 

    public class CompressorFor3Threads : Compressor 
    {
        private volatile State _state;
        public CompressorFor3Threads(QueueAdapter sourceQueue)
            : base(sourceQueue) 
            => _state = new State(ComponentState.canRunFurther);


        public override void Run(Action<ICanRunComponent> onEndRun = null) {
            while (_state.CurrentState == ComponentState.canRunFurther) {
                base.Run();

                Thread.Yield();
            }

            base.Run();

            onEndRun?.Invoke(this);
        }

        public override void Finish() => _state.NextState();

        protected override QueueAdapter GetDestQueue() =>
           new ConcurrentQueueAdapter();
    } 


    public class RunnerFor3Threads : Runner
    {
        public override void Run(
            Slicer slicer,
            Compressor compressor,
            Saver saver) 
        {

            if (slicer == null || compressor == null || saver == null)
                throw new Exception(ComponentsIsRequiredExceptionText);

            new Thread(() => {
                slicer.Run(c => compressor.Finish());
            }).Start();

            new Thread(() => {
                compressor.Run(c => _isCompleted = true);
            }).Start();

            while (!_isCompleted)
                saver.Run();

            saver.Run();

        }
    }

}
