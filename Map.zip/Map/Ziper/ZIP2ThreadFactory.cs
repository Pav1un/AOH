﻿using Map.Queue;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Map.Ziper
{
    public class ZIP2ThreadsFactory : ZIPFactory
    {
        public override Slicer GetSlicer(string path) => new SlicerFor2Threads(path);
        public override Runner GetRunner() => new RunnerFor2Threads();
    }

    public class SlicerFor2Threads : Slicer
    {
        public SlicerFor2Threads(string path, QueueAdapter sourceQueue = null)
            : base(path, sourceQueue) { }

        public override void Run(Action<ICanRunComponent> onEndRun = null) {

            while (_state.CurrentState == ComponentState.canRunFurther) {
                Slice();

                if (_state.CurrentState == ComponentState.finished) {
                    onEndRun?.Invoke(this);
                    _state.NextState();

                    return;
                }

                Thread.Yield();
            }
        } 

        protected override QueueAdapter GetDestQueue() =>
           new ConcurrentQueueAdapter();
    } 


    public class RunnerFor2Threads : Runner
    {
        public override void Run(
            Slicer slicer,
            Compressor compressor,
            Saver saver) 
        {

            if (slicer == null || compressor == null || saver == null)
                throw new Exception(ComponentsIsRequiredExceptionText);

            new Thread(() => {
                slicer.Run((comp) => _isCompleted = true);
            }).Start();

            while (!_isCompleted) {
                compressor.Run();
                saver.Run();
            }

            compressor.Run();
            saver.Run();
        }
    }

}
